package com.zaid.mc475

import kotlin.math.*
import kotlin.random.Random

class Enemy(var x: Float, var z: Float) {
    var hp = 60f
    var attackCd = 0.5f
    var flash = 0f
    var phase = Random.nextFloat() * 6.28f
}

enum class State { PLAYING, DEAD, WON }

class Game(val level: Level) {
    var px = level.startX
    var pz = level.startZ
    var yaw = 0f
    var pitch = 0f
    var hp = 100f
    var ammo = 30
    var reserve = 150
    var reloadT = 0f
    var fireCd = 0f
    var muzzle = 0f
    var recoil = 0f
    var kills = 0
    var time = 0f
    var weldLeft = 90f
    var damageFlash = 0f
    var hitMarker = 0f
    var bob = 0f
    var state = State.PLAYING
    val enemies = ArrayList<Enemy>()
    private var waveT = 2f
    private var wave = 0
    private var fieldT = 0f
    private val field = IntArray(level.w * level.h)
    private val look = FloatArray(2)

    companion object {
        const val MAG = 30
        const val RADIUS = 0.3f
        val LINES = listOf(
            Triple(0f, "GLEN", "Welding the blast door. I need ninety seconds. Hold that corridor, Marcus!"),
            Triple(30f, "GLEN", "Weld's at a third. Don't let them near the door!"),
            Triple(60f, "GLEN", "Two thirds. They're coming from the cargo bay, keep firing!")
        )
    }

    fun fwd(): FloatArray {
        val cp = cos(pitch)
        return floatArrayOf(cp * sin(yaw), sin(pitch), -cp * cos(yaw))
    }

    fun currentLine(): Triple<Float, String, String>? {
        if (state == State.WON) return Triple(0f, "GLEN", "Door sealed. Get inside, now!")
        if (state == State.DEAD) return null
        var best: Triple<Float, String, String>? = null
        for (l in LINES) if (time >= l.first && time < l.first + 6f) best = l
        return best
    }

    fun restart() {
        px = level.startX; pz = level.startZ; yaw = 0f; pitch = 0f
        hp = 100f; ammo = MAG; reserve = 150; reloadT = 0f; fireCd = 0f
        kills = 0; time = 0f; weldLeft = 90f; enemies.clear(); wave = 0; waveT = 2f
        damageFlash = 0f; state = State.PLAYING
    }

    private fun blocked(x: Float, z: Float, r: Float) =
        level.isWall(x - r, z - r) || level.isWall(x + r, z - r) || level.isWall(x - r, z + r) || level.isWall(x + r, z + r)

    private fun hasLos(ax: Float, az: Float, bx: Float, bz: Float): Boolean {
        val d = hypot(bx - ax, bz - az)
        val steps = (d / 0.25f).toInt() + 1
        for (i in 1 until steps) {
            val t = i.toFloat() / steps
            if (level.isWall(ax + (bx - ax) * t, az + (bz - az) * t)) return false
        }
        return true
    }

    private fun buildField() {
        java.util.Arrays.fill(field, -1)
        val sx = px.toInt(); val sz = pz.toInt()
        if (level.cellWall(sx, sz)) return
        val q = java.util.ArrayDeque<Int>()
        field[sz * level.w + sx] = 0; q.add(sz * level.w + sx)
        val dx = intArrayOf(1, -1, 0, 0); val dz = intArrayOf(0, 0, 1, -1)
        while (q.isNotEmpty()) {
            val c = q.poll()!!
            val cx = c % level.w; val cz = c / level.w
            for (k in 0..3) {
                val nx = cx + dx[k]; val nz = cz + dz[k]
                if (level.cellWall(nx, nz)) continue
                val ni = nz * level.w + nx
                if (field[ni] != -1) continue
                field[ni] = field[c] + 1; q.add(ni)
            }
        }
    }

    private fun moveEnemy(e: Enemy, dt: Float) {
        var tx = px; var tz = pz
        if (!hasLos(e.x, e.z, px, pz)) {
            val cx = e.x.toInt(); val cz = e.z.toInt()
            var best = Int.MAX_VALUE; var bx = cx; var bz = cz
            val dx = intArrayOf(1, -1, 0, 0); val dz = intArrayOf(0, 0, 1, -1)
            for (k in 0..3) {
                val nx = cx + dx[k]; val nz = cz + dz[k]
                if (level.cellWall(nx, nz)) continue
                val v = field[nz * level.w + nx]
                if (v in 0 until best) { best = v; bx = nx; bz = nz }
            }
            tx = bx + 0.5f; tz = bz + 0.5f
        }
        val dxx = tx - e.x; val dzz = tz - e.z
        val d = hypot(dxx, dzz)
        if (d < 0.01f) return
        val sp = 4.3f * dt
        val nx = e.x + dxx / d * sp; val nz = e.z + dzz / d * sp
        if (!blocked(nx, e.z, 0.35f)) e.x = nx
        if (!blocked(e.x, nz, 0.35f)) e.z = nz
    }

    private fun wallDistance(ox: Float, oy: Float, oz: Float, d: FloatArray): Float {
        var t = 0f
        while (t < 40f) {
            val x = ox + d[0] * t; val y = oy + d[1] * t; val z = oz + d[2] * t
            if (y < 0f || y > Level.WALL_H || level.isWall(x, z)) return t
            t += 0.1f
        }
        return 40f
    }

    private fun shoot() {
        val sx = 0.012f
        val f = fwd()
        val d = floatArrayOf(f[0] + (Random.nextFloat() - .5f) * sx, f[1] + (Random.nextFloat() - .5f) * sx, f[2] + (Random.nextFloat() - .5f) * sx)
        val ey = 1.6f
        val wt = wallDistance(px, ey, pz, d)
        var best: Enemy? = null; var bt = wt
        for (e in enemies) {
            val vx = e.x - px; val vy = 0.8f - ey; val vz = e.z - pz
            val t = vx * d[0] + vy * d[1] + vz * d[2]
            if (t <= 0f || t >= bt) continue
            val cx = vx - d[0] * t; val cy = vy - d[1] * t; val cz = vz - d[2] * t
            if (sqrt(cx * cx + cy * cy + cz * cz) < 0.6f) { best = e; bt = t }
        }
        best?.let {
            it.hp -= 14f; it.flash = 0.15f; hitMarker = 0.12f
            if (it.hp <= 0f) { enemies.remove(it); kills++ }
        }
    }

    fun update(dt: Float, inp: Input) {
        if (state != State.PLAYING) {
            if (inp.tapped) { inp.tapped = false; if (state != State.PLAYING && time > 1f) restart() }
            time += dt
            return
        }
        inp.tapped = false
        time += dt
        weldLeft -= dt
        if (weldLeft <= 0f) { state = State.WON; time = 0f; return }

        // look
        inp.consumeLook(look)
        yaw += look[0] * 0.0035f
        pitch = (pitch - look[1] * 0.0035f).coerceIn(-1.2f, 1.2f)

        // move
        val mx = inp.moveX; val my = inp.moveY
        val sp = 3.3f * dt
        val fx = sin(yaw); val fz = -cos(yaw)
        val rx = cos(yaw); val rz = sin(yaw)
        val dx = (fx * my + rx * mx) * sp
        val dz = (fz * my + rz * mx) * sp
        if (!blocked(px + dx, pz, RADIUS)) px += dx
        if (!blocked(px, pz + dz, RADIUS)) pz += dz
        if (abs(mx) + abs(my) > 0.1f) bob += dt * 9f

        // weapon
        fireCd -= dt; muzzle = max(0f, muzzle - dt); recoil = max(0f, recoil - dt * 6f)
        hitMarker = max(0f, hitMarker - dt); damageFlash = max(0f, damageFlash - dt * 1.6f)
        if (inp.reloadPressed) { inp.reloadPressed = false; if (reloadT <= 0f && ammo < MAG && reserve > 0) reloadT = 1.8f }
        if (reloadT > 0f) {
            reloadT -= dt
            if (reloadT <= 0f) { val take = min(MAG - ammo, reserve); ammo += take; reserve -= take }
        } else if (inp.firing && fireCd <= 0f) {
            if (ammo > 0) {
                ammo--; fireCd = 0.095f; muzzle = 0.06f; recoil = 1f
                pitch = (pitch + 0.006f).coerceAtMost(1.2f)
                shoot()
            } else if (reserve > 0) reloadT = 1.8f
        }

        // enemies
        fieldT -= dt
        if (fieldT <= 0f) { fieldT = 0.25f; buildField() }
        val iter = enemies.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            e.flash = max(0f, e.flash - dt)
            e.phase += dt * 8f
            moveEnemy(e, dt)
            e.attackCd -= dt
            if (hypot(px - e.x, pz - e.z) < 1.25f && e.attackCd <= 0f) {
                e.attackCd = 0.9f; hp -= 10f; damageFlash = 1f
            }
        }
        if (hp <= 0f) { hp = 0f; state = State.DEAD; time = 0f }

        // waves
        waveT -= dt
        if (waveT <= 0f) {
            wave++; waveT = 9f
            val n = min(2 + wave, 8 - enemies.size)
            val pool = level.spawns.filter { hypot(it[0] - px, it[1] - pz) > 8f }
            repeat(max(0, n)) {
                if (pool.isNotEmpty()) {
                    val s = pool[Random.nextInt(pool.size)]
                    enemies.add(Enemy(s[0] + (Random.nextFloat() - .5f), s[1] + (Random.nextFloat() - .5f)))
                }
            }
        }
    }
}
