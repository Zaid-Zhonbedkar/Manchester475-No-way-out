package com.zaid.mc475

import android.graphics.*
import android.opengl.GLES20
import android.opengl.GLUtils
import kotlin.random.Random

object Textures {
    fun upload(bmp: Bitmap, repeat: Boolean, mip: Boolean): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, if (mip) GLES20.GL_LINEAR_MIPMAP_LINEAR else GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        val wrap = if (repeat) GLES20.GL_REPEAT else GLES20.GL_CLAMP_TO_EDGE
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, wrap)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, wrap)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        if (mip) GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        return ids[0]
    }

    /** Procedural 128x128 ship-hull plating: panels, rivets, grime, optional hazard stripe. */
    fun metal(seed: Int, base: Int, hazard: Boolean): Bitmap {
        val rnd = Random(seed)
        val s = 128
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(base)
        val p = Paint()
        for (i in 0 until 2500) {
            p.color = Color.argb(rnd.nextInt(10, 40), 0, 0, 0)
            c.drawPoint(rnd.nextInt(s).toFloat(), rnd.nextInt(s).toFloat(), p)
            p.color = Color.argb(rnd.nextInt(5, 20), 255, 255, 255)
            c.drawPoint(rnd.nextInt(s).toFloat(), rnd.nextInt(s).toFloat(), p)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.argb(150, 0, 0, 0)
        c.drawRect(1f, 1f, s - 1f, s - 1f, p)
        p.strokeWidth = 2f; p.color = Color.argb(90, 0, 0, 0)
        c.drawLine(0f, 64f, s.toFloat(), 64f, p)
        c.drawLine(64f, 0f, 64f, 64f, p)
        p.style = Paint.Style.FILL; p.color = Color.argb(140, 20, 20, 20)
        for (x in intArrayOf(8, 120)) for (y in intArrayOf(8, 56, 72, 120)) c.drawCircle(x.toFloat(), y.toFloat(), 2.5f, p)
        // grime streaks
        for (i in 0 until 6) {
            p.color = Color.argb(rnd.nextInt(20, 50), 10, 8, 4)
            val x = rnd.nextInt(s).toFloat()
            c.drawRect(x, 0f, x + rnd.nextInt(2, 6), rnd.nextInt(30, s).toFloat(), p)
        }
        if (hazard) {
            p.color = Color.argb(200, 220, 170, 20)
            val path = Path()
            var x = -s
            while (x < s * 2) { path.reset(); path.moveTo(x.toFloat(), s.toFloat()); path.lineTo(x + 12f, s.toFloat()); path.lineTo(x + 28f, s - 14f); path.lineTo(x + 16f, s - 14f); path.close(); c.drawPath(path, p); x += 24 }
        }
        return b
    }
}
