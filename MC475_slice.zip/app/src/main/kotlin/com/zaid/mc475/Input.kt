package com.zaid.mc475

/** Shared touch state. Written by the UI thread, read by the GL thread. */
class Input {
    @Volatile var w = 1280f
    @Volatile var h = 720f
    @Volatile var moveX = 0f
    @Volatile var moveY = 0f
    @Volatile var firing = false
    @Volatile var reloadPressed = false
    @Volatile var tapped = false
    @Volatile var stickActive = false
    @Volatile var baseX = 0f
    @Volatile var baseY = 0f
    @Volatile var knobX = 0f
    @Volatile var knobY = 0f
    private var lookX = 0f
    private var lookY = 0f

    val r get() = h * 0.12f
    val fireX get() = w - r * 1.8f
    val fireY get() = h - r * 2.0f
    val reloadX get() = w - r * 4.0f
    val reloadY get() = h - r * 1.3f
    val reloadR get() = r * 0.7f
    val stickMax get() = r * 1.6f

    @Synchronized fun addLook(dx: Float, dy: Float) { lookX += dx; lookY += dy }
    @Synchronized fun consumeLook(out: FloatArray) { out[0] = lookX; out[1] = lookY; lookX = 0f; lookY = 0f }
}
