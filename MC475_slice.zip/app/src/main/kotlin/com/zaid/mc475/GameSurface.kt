package com.zaid.mc475

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import kotlin.math.hypot

@SuppressLint("ViewConstructor")
class GameSurface(ctx: Context) : GLSurfaceView(ctx) {
    private val input = Input()
    private val game = Game(Level())
    private var moveId = -1
    private var lookId = -1
    private var fireId = -1
    private var lastX = 0f
    private var lastY = 0f

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        setRenderer(GameRenderer(ctx, game, input))
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        input.w = width.toFloat(); input.h = height.toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                val x = e.getX(i); val y = e.getY(i)
                input.tapped = true
                if (hypot(x - input.fireX, y - input.fireY) < input.r * 1.3f && fireId == -1) {
                    fireId = id; input.firing = true
                } else if (hypot(x - input.reloadX, y - input.reloadY) < input.reloadR * 1.3f) {
                    input.reloadPressed = true
                } else if (x < width * 0.45f && moveId == -1) {
                    moveId = id
                    input.stickActive = true
                    input.baseX = x; input.baseY = y; input.knobX = x; input.knobY = y
                } else if (lookId == -1) {
                    lookId = id; lastX = x; lastY = y
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    val x = e.getX(i); val y = e.getY(i)
                    if (id == moveId) {
                        var dx = x - input.baseX; var dy = y - input.baseY
                        val d = hypot(dx, dy); val m = input.stickMax
                        if (d > m) { dx = dx / d * m; dy = dy / d * m }
                        input.knobX = input.baseX + dx; input.knobY = input.baseY + dy
                        input.moveX = dx / m; input.moveY = -dy / m
                    } else if (id == lookId) {
                        input.addLook(x - lastX, y - lastY)
                        lastX = x; lastY = y
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = if (e.actionMasked == MotionEvent.ACTION_CANCEL) -2 else e.getPointerId(e.actionIndex)
                if (id == moveId || id == -2) { moveId = -1; input.stickActive = false; input.moveX = 0f; input.moveY = 0f }
                if (id == lookId || id == -2) lookId = -1
                if (id == fireId || id == -2) { fireId = -1; input.firing = false }
            }
        }
        return true
    }
}
