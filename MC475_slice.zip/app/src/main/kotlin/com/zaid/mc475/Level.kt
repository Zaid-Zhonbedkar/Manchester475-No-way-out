package com.zaid.mc475

import kotlin.math.floor

/** Chapter 2 "First Blood": cargo-bay corridors of The Man475. '#' wall, '.' floor, 'P' player, 'S' stalker spawn. */
class Level {
    companion object {
        const val WALL_H = 3f
        val MAP = listOf(
            "##############################",
            "#SS.....#...........#......SS#",
            "#.......#...........#........#",
            "#.......#....###....#........#",
            "#.......#....#.#....#...##...#",
            "#..###......##.##......#..#..#",
            "#..#.#..........##.....#..#..#",
            "#..###..#####...##..#####.##.#",
            "#.......#...........#........#",
            "#.......#...........#........#",
            "#..####.#...........#.####...#",
            "#..#..#.#####..######.#..#...#",
            "#..#..#...............#..#...#",
            "#..####...............####...#",
            "#.......#####..######........#",
            "#.......#...#..#....#........#",
            "#...P...#...#..#....#.......S#",
            "#.......#...#..#....#.......S#",
            "##############################"
        )
    }

    val w = MAP[0].length
    val h = MAP.size
    var startX = 1.5f
    var startZ = 1.5f
    val spawns = ArrayList<FloatArray>()

    init {
        for (z in 0 until h) for (x in 0 until w) {
            when (MAP[z][x]) {
                'P' -> { startX = x + 0.5f; startZ = z + 0.5f }
                'S' -> spawns.add(floatArrayOf(x + 0.5f, z + 0.5f))
            }
        }
    }

    fun cellWall(cx: Int, cz: Int): Boolean {
        if (cx < 0 || cz < 0 || cx >= w || cz >= h) return true
        return MAP[cz][cx] == '#'
    }

    fun isWall(x: Float, z: Float): Boolean = cellWall(floor(x).toInt(), floor(z).toInt())

    private fun quad(out: ArrayList<Float>, a: FloatArray, b: FloatArray, c: FloatArray, d: FloatArray) {
        for (p in arrayOf(a, b, c, a, c, d)) for (v in p) out.add(v)
    }

    fun buildWalls(): FloatArray {
        val o = ArrayList<Float>()
        val H = WALL_H
        for (z in 0 until h) for (x in 0 until w) {
            if (!cellWall(x, z)) continue
            val xf = x.toFloat(); val zf = z.toFloat()
            if (!cellWall(x, z - 1)) quad(o, floatArrayOf(xf, 0f, zf, 0f, 0f), floatArrayOf(xf + 1, 0f, zf, 1f, 0f), floatArrayOf(xf + 1, H, zf, 1f, 2f), floatArrayOf(xf, H, zf, 0f, 2f))
            if (!cellWall(x, z + 1)) quad(o, floatArrayOf(xf, 0f, zf + 1, 0f, 0f), floatArrayOf(xf + 1, 0f, zf + 1, 1f, 0f), floatArrayOf(xf + 1, H, zf + 1, 1f, 2f), floatArrayOf(xf, H, zf + 1, 0f, 2f))
            if (!cellWall(x - 1, z)) quad(o, floatArrayOf(xf, 0f, zf, 0f, 0f), floatArrayOf(xf, 0f, zf + 1, 1f, 0f), floatArrayOf(xf, H, zf + 1, 1f, 2f), floatArrayOf(xf, H, zf, 0f, 2f))
            if (!cellWall(x + 1, z)) quad(o, floatArrayOf(xf + 1, 0f, zf, 0f, 0f), floatArrayOf(xf + 1, 0f, zf + 1, 1f, 0f), floatArrayOf(xf + 1, H, zf + 1, 1f, 2f), floatArrayOf(xf + 1, H, zf, 0f, 2f))
        }
        return o.toFloatArray()
    }

    fun buildPlane(y: Float): FloatArray {
        val o = ArrayList<Float>()
        for (z in 0 until h) for (x in 0 until w) {
            if (cellWall(x, z)) continue
            val xf = x.toFloat(); val zf = z.toFloat()
            quad(o, floatArrayOf(xf, y, zf, 0f, 0f), floatArrayOf(xf + 1, y, zf, 1f, 0f), floatArrayOf(xf + 1, y, zf + 1, 1f, 1f), floatArrayOf(xf, y, zf + 1, 0f, 1f))
        }
        return o.toFloatArray()
    }
}
