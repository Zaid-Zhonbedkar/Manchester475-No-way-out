package com.zaid.mc475

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

private class Mesh(data: FloatArray) {
    val count = data.size / 5
    val buf: FloatBuffer = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { it.put(data); it.position(0) }
    fun draw(aPos: Int, aUV: Int) {
        buf.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 20, buf)
        GLES20.glEnableVertexAttribArray(aPos)
        buf.position(3)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 20, buf)
        GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
    }
}

class GameRenderer(private val ctx: Context, private val game: Game, private val input: Input) : GLSurfaceView.Renderer {
    private val VS = """
        uniform mat4 uMVP; attribute vec3 aPos; attribute vec2 aUV;
        varying vec2 vUV; varying vec3 vWorld;
        void main(){ vUV=aUV; vWorld=aPos; gl_Position=uMVP*vec4(aPos,1.0); }"""
    private val FS = """
        precision mediump float;
        uniform sampler2D uTex; uniform vec3 uCam; uniform vec3 uFwd; uniform vec4 uTint;
        uniform float uMask; uniform float uAmbient;
        varying vec2 vUV; varying vec3 vWorld;
        void main(){
          vec4 c = texture2D(uTex, vUV);
          vec3 d = vWorld - uCam; float dist = length(d); vec3 dir = d / max(dist, 0.001);
          float cone = smoothstep(0.78, 0.95, dot(dir, uFwd));
          float flash = cone * clamp(1.0 - dist / 18.0, 0.0, 1.0);
          float amb = uAmbient / (1.0 + dist * 0.45);
          float light = clamp(amb + flash * 1.3, 0.0, 1.5);
          float a = 1.0;
          if (uMask > 0.5) {
            vec2 p = (vUV - vec2(0.5)) * 2.0;
            a = 1.0 - smoothstep(0.55, 0.98, length(p * vec2(1.0, 1.05)));
            if (a < 0.02) discard;
          }
          gl_FragColor = vec4(c.rgb * light * uTint.rgb + uTint.a * vec3(0.6, 0.0, 0.0), a);
        }"""
    private val HVS = """
        attribute vec2 aPos; attribute vec2 aUV; varying vec2 vUV;
        void main(){ vUV=aUV; gl_Position=vec4(aPos,0.0,1.0); }"""
    private val HFS = """
        precision mediump float; uniform sampler2D uTex; varying vec2 vUV;
        void main(){ gl_FragColor = texture2D(uTex, vUV); }"""

    private var prog = 0; private var hudProg = 0
    private var aPos = 0; private var aUV = 0; private var uMVP = 0; private var uTex = 0
    private var uCam = 0; private var uFwd = 0; private var uTint = 0; private var uMask = 0; private var uAmbient = 0
    private var hPos = 0; private var hUV = 0; private var hTex = 0
    private lateinit var walls: Mesh; private lateinit var floor: Mesh; private lateinit var ceil: Mesh
    private var wallTex = 0; private var floorTex = 0; private var ceilTex = 0; private var stalkerTex = 0
    private lateinit var hud: Hud
    private lateinit var hudBmp: Bitmap
    private lateinit var hudCanvas: Canvas
    private var hudTex = 0
    private var hudW = 1024; private var hudH = 576
    private var vw = 1280; private var vh = 720
    private val proj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16)
    private val spriteBuf: FloatBuffer = ByteBuffer.allocateDirect(30 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val quadBuf: FloatBuffer = ByteBuffer.allocateDirect(24 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
        it.put(floatArrayOf(-1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f, -1f, -1f, 0f, 1f, 1f, -1f, 1f, 1f)); it.position(0)
    }
    private var last = System.nanoTime()

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
        val ok = IntArray(1); GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun link(v: String, f: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, v))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, f))
        GLES20.glLinkProgram(p)
        return p
    }

    private fun asset(name: String): Bitmap = ctx.assets.open(name).use { BitmapFactory.decodeStream(it) }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = link(VS, FS)
        aPos = GLES20.glGetAttribLocation(prog, "aPos"); aUV = GLES20.glGetAttribLocation(prog, "aUV")
        uMVP = GLES20.glGetUniformLocation(prog, "uMVP"); uTex = GLES20.glGetUniformLocation(prog, "uTex")
        uCam = GLES20.glGetUniformLocation(prog, "uCam"); uFwd = GLES20.glGetUniformLocation(prog, "uFwd")
        uTint = GLES20.glGetUniformLocation(prog, "uTint"); uMask = GLES20.glGetUniformLocation(prog, "uMask")
        uAmbient = GLES20.glGetUniformLocation(prog, "uAmbient")
        hudProg = link(HVS, HFS)
        hPos = GLES20.glGetAttribLocation(hudProg, "aPos"); hUV = GLES20.glGetAttribLocation(hudProg, "aUV")
        hTex = GLES20.glGetUniformLocation(hudProg, "uTex")

        walls = Mesh(game.level.buildWalls()); floor = Mesh(game.level.buildPlane(0f)); ceil = Mesh(game.level.buildPlane(Level.WALL_H))
        wallTex = Textures.upload(Textures.metal(1, Color.rgb(78, 84, 92), true), true, true)
        floorTex = Textures.upload(Textures.metal(2, Color.rgb(46, 48, 52), false), true, true)
        ceilTex = Textures.upload(Textures.metal(3, Color.rgb(36, 38, 42), false), true, true)
        stalkerTex = Textures.upload(asset("stalker.jpg"), false, false)
        hud = Hud(asset("portrait_marcus.jpg"), asset("portrait_glen.jpg"))
        GLES20.glClearColor(0.01f, 0.015f, 0.02f, 1f)
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        vw = w; vh = h
        GLES20.glViewport(0, 0, w, h)
        hudW = 1024; hudH = (1024f * h / w).toInt().coerceAtLeast(256)
        hudBmp = Bitmap.createBitmap(hudW, hudH, Bitmap.Config.ARGB_8888)
        hudCanvas = Canvas(hudBmp)
        hudTex = Textures.upload(hudBmp, false, false)
        input.w = w.toFloat(); input.h = h.toFloat()
        Matrix.perspectiveM(proj, 0, 70f, w.toFloat() / h, 0.05f, 60f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        var dt = (now - last) / 1e9f; last = now
        if (dt > 0.05f) dt = 0.05f
        game.update(dt, input)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST); GLES20.glDisable(GLES20.GL_CULL_FACE); GLES20.glDisable(GLES20.GL_BLEND)

        val ey = 1.6f + sin(game.bob) * 0.03f
        val f = game.fwd()
        Matrix.setLookAtM(view, 0, game.px, ey, game.pz, game.px + f[0], ey + f[1], game.pz + f[2], 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        GLES20.glUseProgram(prog)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, vp, 0)
        GLES20.glUniform3f(uCam, game.px, ey, game.pz)
        GLES20.glUniform3f(uFwd, f[0], f[1], f[2])
        GLES20.glUniform1f(uAmbient, 1.1f)
        GLES20.glUniform4f(uTint, 1f, 1f, 1f, 0f)
        GLES20.glUniform1f(uMask, 0f)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glUniform1i(uTex, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, wallTex); walls.draw(aPos, aUV)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, floorTex); floor.draw(aPos, aUV)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ceilTex); ceil.draw(aPos, aUV)

        // enemy billboards, far to near
        GLES20.glEnable(GLES20.GL_BLEND); GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUniform1f(uMask, 1f)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, stalkerTex)
        val rx = cos(game.yaw); val rz = sin(game.yaw)
        val sorted = game.enemies.sortedByDescending { hypot(it.x - game.px, it.z - game.pz) }
        for (e in sorted) {
            val hw = 1.3f; val bobY = sin(e.phase) * 0.05f
            val h0 = bobY; val h1 = 1.75f + bobY
            spriteBuf.position(0)
            fun v(sx: Float, y: Float, u: Float, t: Float) { spriteBuf.put(e.x + rx * hw * sx); spriteBuf.put(y); spriteBuf.put(e.z + rz * hw * sx); spriteBuf.put(u); spriteBuf.put(t) }
            v(-1f, h0, 0f, 1f); v(1f, h0, 1f, 1f); v(1f, h1, 1f, 0f)
            v(-1f, h0, 0f, 1f); v(1f, h1, 1f, 0f); v(-1f, h1, 0f, 0f)
            GLES20.glUniform4f(uTint, 1f, 1f, 1f, if (e.flash > 0f) 0.8f else 0f)
            spriteBuf.position(0)
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 20, spriteBuf)
            GLES20.glEnableVertexAttribArray(aPos)
            spriteBuf.position(3)
            GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 20, spriteBuf)
            GLES20.glEnableVertexAttribArray(aUV)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
        }

        // HUD overlay
        hudBmp.eraseColor(Color.TRANSPARENT)
        hud.draw(hudCanvas, game, input, hudW.toFloat() / vw)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(hudProg)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, hudTex)
        GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, hudBmp)
        GLES20.glUniform1i(hTex, 0)
        quadBuf.position(0); GLES20.glVertexAttribPointer(hPos, 2, GLES20.GL_FLOAT, false, 16, quadBuf); GLES20.glEnableVertexAttribArray(hPos)
        quadBuf.position(2); GLES20.glVertexAttribPointer(hUV, 2, GLES20.GL_FLOAT, false, 16, quadBuf); GLES20.glEnableVertexAttribArray(hUV)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }
}
