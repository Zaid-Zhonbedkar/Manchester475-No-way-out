package com.zaid.mc475

import android.graphics.*
import kotlin.math.min

/** All 2D overlay drawing: crosshair, weapon, bars, dialogue, touch controls. Drawn in view-pixel coordinates. */
class Hud(private val marcus: Bitmap, private val glen: Bitmap) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT, bold: Boolean = true) {
        p.style = Paint.Style.FILL; p.shader = null
        p.textSize = size; p.color = color; p.textAlign = align
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        c.drawText(s, x, y, p)
    }

    fun draw(c: Canvas, g: Game, inp: Input, scale: Float) {
        c.save(); c.scale(scale, scale)
        val w = inp.w; val h = inp.h
        val u = h / 720f

        // damage vignette
        if (g.damageFlash > 0f) {
            p.shader = RadialGradient(w / 2, h / 2, w * 0.7f, intArrayOf(Color.TRANSPARENT, Color.argb((170 * g.damageFlash).toInt(), 170, 0, 0)), floatArrayOf(0.45f, 1f), Shader.TileMode.CLAMP)
            p.style = Paint.Style.FILL; c.drawRect(0f, 0f, w, h, p); p.shader = null
        }

        drawWeapon(c, g, w, h, u)

        // crosshair
        val cx = w / 2; val cy = h / 2
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * u
        p.color = if (g.hitMarker > 0f) Color.rgb(255, 70, 70) else Color.argb(220, 120, 255, 230)
        val gap = 7f * u; val len = 9f * u
        c.drawLine(cx - gap - len, cy, cx - gap, cy, p); c.drawLine(cx + gap, cy, cx + gap + len, cy, p)
        c.drawLine(cx, cy - gap - len, cx, cy - gap, p); c.drawLine(cx, cy + gap, cx, cy + gap + len, p)

        // objective: weld progress (top center)
        val bw = w * 0.34f; val bx = (w - bw) / 2; val by = 18f * u
        text(c, "DOOR WELD  " + (g.weldLeft.coerceAtLeast(0f)).toInt() + "s", w / 2, by + 12f * u, 15f * u, Color.argb(230, 255, 210, 90), Paint.Align.CENTER)
        p.style = Paint.Style.FILL; p.color = Color.argb(140, 0, 0, 0); rect.set(bx, by + 20f * u, bx + bw, by + 30f * u); c.drawRoundRect(rect, 4f, 4f, p)
        p.color = Color.rgb(255, 190, 40); rect.set(bx, by + 20f * u, bx + bw * (1f - g.weldLeft / 90f).coerceIn(0f, 1f), by + 30f * u); c.drawRoundRect(rect, 4f, 4f, p)

        // health (top-right) Dead-Space-style segmented spine
        val segs = 10; val sx = w - 40f * u - segs * 16f * u; val sy = 22f * u
        for (i in 0 until segs) {
            val on = g.hp > i * 10f
            p.style = Paint.Style.FILL
            p.color = if (on) (if (g.hp < 35f) Color.rgb(230, 50, 40) else Color.rgb(90, 230, 255)) else Color.argb(90, 60, 60, 60)
            rect.set(sx + i * 16f * u, sy, sx + i * 16f * u + 12f * u, sy + 26f * u); c.drawRoundRect(rect, 3f, 3f, p)
        }
        text(c, "KILLS " + g.kills, w - 40f * u, sy + 52f * u, 14f * u, Color.argb(200, 220, 220, 220), Paint.Align.RIGHT)

        // ammo (bottom center-right)
        val ax = w * 0.5f
        text(c, g.ammo.toString(), ax, h - 28f * u, 44f * u, if (g.ammo <= 6) Color.rgb(255, 80, 60) else Color.WHITE, Paint.Align.RIGHT)
        text(c, " / " + g.reserve, ax, h - 28f * u, 22f * u, Color.argb(200, 200, 200, 200))
        if (g.reloadT > 0f) text(c, "RELOADING", cx, cy + 70f * u, 18f * u, Color.argb(230, 255, 210, 90), Paint.Align.CENTER)

        // dialogue
        val line = g.currentLine()
        if (line != null) {
            val dx = 20f * u; val dy = 18f * u; val ps = 76f * u
            p.style = Paint.Style.FILL; p.color = Color.argb(170, 4, 10, 18); rect.set(dx, dy, dx + w * 0.42f, dy + ps + 10f * u); c.drawRoundRect(rect, 10f, 10f, p)
            c.drawBitmap(glen, Rect(0, 0, glen.width, glen.height), RectF(dx + 5f * u, dy + 5f * u, dx + 5f * u + ps, dy + 5f * u + ps), p)
            text(c, "CHIEF ENGINEER G. PETERSON", dx + ps + 16f * u, dy + 26f * u, 13f * u, Color.rgb(110, 190, 255))
            wrap(c, line.third, dx + ps + 16f * u, dy + 48f * u, w * 0.42f - ps - 30f * u, 15f * u)
        }
        // player portrait (bottom-left above stick zone is busy; keep small, top area under dialogue)
        p.style = Paint.Style.FILL
        rect.set(20f * u, h - 100f * u, 20f * u + 70f * u, h - 30f * u)
        p.color = Color.argb(150, 4, 10, 18); c.drawRoundRect(RectF(rect.left - 4f * u, rect.top - 4f * u, rect.right + 4f * u, rect.bottom + 4f * u), 8f, 8f, p)
        c.drawBitmap(marcus, Rect(0, 0, marcus.width, marcus.height), rect, p)

        // touch controls
        drawControls(c, inp, g)

        // end screens
        if (g.state != State.PLAYING) {
            p.style = Paint.Style.FILL; p.color = Color.argb(170, 0, 0, 0); c.drawRect(0f, 0f, w, h, p)
            if (g.state == State.DEAD) {
                text(c, "MARCUS VANCE IS DOWN", w / 2, h / 2 - 10f * u, 40f * u, Color.rgb(230, 60, 50), Paint.Align.CENTER)
            } else {
                text(c, "BLAST DOORS SEALED", w / 2, h / 2 - 10f * u, 40f * u, Color.rgb(255, 210, 90), Paint.Align.CENTER)
                text(c, "Chapter 2 complete  |  Kills: " + g.kills, w / 2, h / 2 + 28f * u, 20f * u, Color.WHITE, Paint.Align.CENTER)
            }
            if (g.time > 1f) text(c, "Tap to restart", w / 2, h / 2 + 70f * u, 18f * u, Color.argb(220, 200, 200, 200), Paint.Align.CENTER)
        }
        c.restore()
    }

    private fun wrap(c: Canvas, s: String, x: Float, y: Float, maxW: Float, size: Float) {
        p.textSize = size; p.typeface = Typeface.DEFAULT
        var line = ""; var yy = y
        for (word in s.split(" ")) {
            val t = if (line.isEmpty()) word else "$line $word"
            if (p.measureText(t) > maxW) { text(c, line, x, yy, size, Color.WHITE, Paint.Align.LEFT, false); yy += size * 1.25f; line = word } else line = t
        }
        if (line.isNotEmpty()) text(c, line, x, yy, size, Color.WHITE, Paint.Align.LEFT, false)
    }

    private fun drawControls(c: Canvas, inp: Input, g: Game) {
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.argb(70, 255, 255, 255)
        if (inp.stickActive) {
            c.drawCircle(inp.baseX, inp.baseY, inp.stickMax, p)
            p.style = Paint.Style.FILL; p.color = Color.argb(90, 255, 255, 255); c.drawCircle(inp.knobX, inp.knobY, inp.r * 0.55f, p)
        }
        // fire
        p.style = Paint.Style.FILL; p.color = Color.argb(if (inp.firing) 140 else 70, 255, 80, 60); c.drawCircle(inp.fireX, inp.fireY, inp.r, p)
        p.style = Paint.Style.STROKE; p.color = Color.argb(150, 255, 255, 255); c.drawCircle(inp.fireX, inp.fireY, inp.r, p)
        text(c, "FIRE", inp.fireX, inp.fireY + 6f, inp.r * 0.3f, Color.argb(220, 255, 255, 255), Paint.Align.CENTER)
        // reload
        p.style = Paint.Style.FILL; p.color = Color.argb(70, 255, 255, 255); c.drawCircle(inp.reloadX, inp.reloadY, inp.reloadR, p)
        text(c, "R", inp.reloadX, inp.reloadY + inp.reloadR * 0.3f, inp.reloadR * 0.9f, Color.argb(220, 255, 255, 255), Paint.Align.CENTER)
    }

    /** Pulse Rifle Mk.IV silhouette, matching the arsenal art: gunmetal body, yellow accents, launcher under barrel. */
    private fun drawWeapon(c: Canvas, g: Game, w: Float, h: Float, u: Float) {
        c.save()
        val kick = g.recoil * 14f * u
        c.translate(w * 0.60f + kick * 0.4f, h + 10f * u + kick)
        c.rotate(-9f - g.recoil * 1.5f)
        c.scale(u * 0.9f, u * 0.9f)
        p.style = Paint.Style.FILL
        fun box(l: Float, t: Float, r: Float, b: Float, col: Int) { p.color = col; rect.set(l, t, r, b); c.drawRoundRect(rect, 6f, 6f, p) }
        box(-230f, -150f, -90f, -95f, 0xFF2a2c2f.toInt())          // stock
        box(-110f, -175f, 250f, -95f, 0xFF45494d.toInt())          // receiver
        box(250f, -160f, 470f, -125f, 0xFF2f3236.toInt())          // handguard
        box(470f, -150f, 560f, -135f, 0xFF1d1f21.toInt())          // barrel
        box(250f, -122f, 440f, -95f, 0xFF3a3e42.toInt())           // under-barrel launcher
        box(0f, -95f, 55f, 25f, 0xFF2a2c2f.toInt())                // magazine
        box(0f, -70f, 55f, -55f, 0xFFE0A81C.toInt())               // yellow mag band
        box(-60f, -95f, -15f, -20f, 0xFF33363a.toInt())            // grip
        box(60f, -205f, 200f, -175f, 0xFF1f2124.toInt())           // optic
        box(185f, -200f, 205f, -180f, 0xFF3fd0ff.toInt())          // lens
        box(110f, -172f, 175f, -160f, 0xFFE0A81C.toInt())          // yellow accent
        if (g.muzzle > 0f) {
            p.shader = RadialGradient(575f, -142f, 120f, intArrayOf(Color.argb(255, 255, 240, 170), Color.argb(200, 255, 140, 30), Color.TRANSPARENT), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(575f, -142f, 120f, p); p.shader = null
        }
        c.restore()
    }
}
