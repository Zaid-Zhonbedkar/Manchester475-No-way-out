# Manchester475: No Way Out (v0.1 vertical slice)
Native Android, Kotlin, OpenGL ES 2.0. No game engine, no third-party libraries.

## Build
1. Open this folder in Android Studio (Koala or newer). Let it sync (it creates the Gradle wrapper).
2. Plug in a phone (USB debugging) and press Run. Landscape only.

## Controls
- Left half: drag = move. Right half: drag = look.
- FIRE (bottom right) hold to shoot. R = reload.

## Slice contents: Chapter 2 "First Blood"
Play Marcus Vance. Hold the cargo-bay corridors for 90s while Glen welds the blast door.
Viper-Mandible Stalkers hunt you with grid pathfinding. Pulse Rifle Mk.IV, flashlight cone, fog-dark lighting.

## Code map (app/src/main/kotlin/com/zaid/mc475)
Level.kt map + mesh generation | Game.kt rules, AI, weapons | GameRenderer.kt GLES2 renderer
Hud.kt overlay + touch UI | Input.kt / GameSurface.kt touch | Textures.kt procedural hull textures
Assets: stalker.jpg, portrait_marcus.jpg, portrait_glen.jpg (from your art).
